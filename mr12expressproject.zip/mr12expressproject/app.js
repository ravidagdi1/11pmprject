const express = require('express')// function
  const app=  express()//module
 const pageRouter= require('./routers/pages');
 const adminRouter= require('./routers/admin')
 const mongoose =require('mongoose')//module
 app.use(express.urlencoded({extended:false}))
 const session= require('express-session');//module
const { Store } = require('express-session');
 const mongodbSession=require('connect-mongodb-session')(session);

 dbUrl ='mongodb://127.0.0.1:27017/mr12project'
 mongoose.connect(dbUrl,()=>{
   console.log("connected to Database mr12project")
 })

 const store =new mongodbSession({
   uri:dbUrl,
   collection:'mySessions'
 })

 app.use(session({
   secret:'ravi',
   resave:false,
   saveUninitialized:false,
   store:store
 }))



 app.use(express.static('public'))
app.set('view engine','ejs');

app.use(pageRouter)
app.use('/admin',adminRouter)


  app.listen(5000,()=>{
    console.log("server is running on 5000")
  })