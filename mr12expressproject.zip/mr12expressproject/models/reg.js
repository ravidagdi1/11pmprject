const mongoose = require('mongoose')

const regSchema= mongoose.Schema({
    username:String,
    password:String,
    email:String,
    status:String
})

 module.exports=mongoose.model('reg',regSchema)