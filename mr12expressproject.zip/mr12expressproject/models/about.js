const mongoose= require('mongoose')//module

const aboutSchema= mongoose.Schema({
    title:String,
    sdesc:String,
    desc: String
})

module.exports =mongoose.model('about',aboutSchema)