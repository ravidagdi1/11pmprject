const mongoose =require("mongoose")

const contactSchema=mongoose.Schema({
    email:String,
    query:String,
    status:String,
     postedDate:Date
})

module.exports=mongoose.model('contact',contactSchema)