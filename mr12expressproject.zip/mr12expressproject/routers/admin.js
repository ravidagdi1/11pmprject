const router = require('express').Router()
const Admin = require('../models/admin')
const session = require('express-session');
const res = require('express/lib/response');
const Banner = require('../models/banner');
const About = require('../models/about');
const Contact = require('../models/contact')
const Reg = require('../models/reg')

const auth = (req, res, next) => {
    if (req.session.isAuth) {
        next()
    } else {
        res.redirect('/admin/')
    }
}

router.get('/', (req, res) => {
    res.render('admin/login.ejs')
})

router.get('/dashboard', auth, async (req, res) => {
    const bannerRecord = await Banner.findOne()
    res.render('admin/dashboard', { bannerRecord: bannerRecord })

})
router.post('/dashboard', auth, async (req, res) => {
    const bannerRecord = await Banner.findOne()
    res.render('admin/dashboard', { bannerRecord: bannerRecord })

})

router.post('/logout', (req, res) => {
    req.session.destroy()
    res.redirect('/admin/')
})

router.post('/', async (req, res) => {
    const username = req.body.username
    const password = req.body.password
    const admin = await Admin.findOne({ username: username })
    //console.log(admin);
    if (admin !== null) {
        if (admin.password == password) {
            req.session.isAuth = true;
            res.redirect('/admin/dashboard/')
        } else {
            res.redirect('/admin/')
        }

    } else {
        res.redirect('/admin/')
    }

})

router.post('/bannerupdate', async (req, res) => {
    const bannerData = await Banner.findOne()
    res.render('admin/bannerupdate.ejs', { bannerData: bannerData })
})

router.post('/bannerupdaterecords/:id', async (req, res) => {
    const id = req.params.id
    const title = req.body.title
    const sdesc = req.body.sdesc
    const desc = req.body.desc
    //console.log(id)
    await Banner.findByIdAndUpdate(id, { title: title, sdesc: sdesc, desc: desc })
    res.redirect('/admin/dashboard')
})

router.get('/adminaboutabout', async (req, res) => {
    const aboutRecord = await About.findOne()
    res.render('admin/about.ejs', { aboutRecord: aboutRecord })
})

router.get('/test', async (req, res) => {
    const title = 'About'
    const sdesc = 'Hello'
    const desc = 'Welcome to Banner  section'
    const about = new About({ title: title, sdesc: sdesc, desc: desc })
    await about.save()
})
router.get('/aboutupdate/:id', async (req, res) => {
    const id = req.params.id
    const aboutUpdate = await About.findById(id)
    res.render('admin/aboutupdate.ejs', { aboutUpdate: aboutUpdate })
})
router.post('/aboutupdaterecords/:id', async (req, res) => {
    //console.log(req.body)
    const id = req.params.id
    const title = req.body.title
    const sdesc = req.body.sdesc
    const desc = req.body.desc
    await About.findByIdAndUpdate(id, { title: title, sdesc: sdesc, desc: desc })
    res.redirect('/admin/adminaboutabout')
})

router.get('/contactformdeatils', async (req, res) => {
    const contactREcord = await Contact.find().sort({postedDate:-1}) 
    //console.log(contactREcord)
    res.render('admin/contactform.ejs', { contactREcord: contactREcord })

})
router.post('/contactsearch', async(req,res)=>{
    const sreachParma = req.body.contactsearch
     const  contactREcord= await Contact.find({status:sreachParma}).sort({postedDate:-1}) 
     res.render('admin/contactform.ejs', { contactREcord: contactREcord })
})

router.post('/contactStatusUpdate/:id', async (req, res) => {
    const id = req.params.id
    const contactUpdate = await Contact.findById(id)
    const email = contactUpdate.email
    const query = contactUpdate.query
    const status = contactUpdate.status
    let status1 = null;
    if(status == 'read'){
         status1 ='unread'
    }else{
        status1 ='read'
    }
    //const status = 'read'
    await Contact.findByIdAndUpdate(id, { email: email, query: query, status: status1 })
    res.redirect('/admin/contactformdeatils')


})

router.get('/contactdelete/:id',async(req,res)=>{
    const id = req.params.id;
        await Contact.findByIdAndDelete(id)
        res.redirect('/admin/contactformdeatils')
})

router.get('/reg',async(req,res)=>{
    const regRecords=await Reg.find()
    res.render('admin/reg.ejs',{regRecords:regRecords})
})

router.post('/regstatusUpdate/:id',async(req,res)=>{
       const id = req.params.id
      const regRecord = await Reg.findById(id)
      const username =regRecord.username 
      const password =regRecord.password 
      const email =regRecord.email
      let statusChange = null
      if(regRecord.status =='inactive'){
        statusChange='active'
      }else{
        statusChange='inactive' 
      }
      await Reg.findByIdAndUpdate(id,{username:username,password:password,email:email,status:statusChange})
      res.redirect('/admin/reg')
})

module.exports = router;
