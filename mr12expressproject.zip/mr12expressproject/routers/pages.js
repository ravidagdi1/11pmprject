const router=require('express').Router()//module
const Banner =require('../models/banner')
const About =require('../models/about')
const Contact = require('../models/contact');
const Reg = require('../models/reg');


router.get('/', async(req,res)=>{
   const bannerData= await  Banner.findOne()
   const aboutRecord= await About.findOne()
    res.render('index.ejs',{bannerData:bannerData,aboutRecord:aboutRecord})
})

router.get('/banner', async(req,res)=>{
    const bannerData= await  Banner.findOne()
    res.render('banner.ejs',{bannerData:bannerData})
})

router.get('/about', async(req,res)=>{
    const aboutRecord =await About.findOne()
    res.render('about.ejs',{aboutRecord:aboutRecord})
})

router.post('/contact',async(req,res)=>{
    //console.log(req.body)
    const email = req.body.email
    const query = req.body.query
    const status= 'unread'
    const postedDate= new Date()
    const contactRecord= new Contact({email:email,query:query,status:status,postedDate:postedDate})
     await contactRecord.save()
     res.redirect('/')


})

router.get('/reg',(req,res)=>{
    res.render('registration.ejs')
})

router.post('/reg', async(req,res)=>{
 const username =req.body.username
 const password =req.body.password
 const email =req.body.email
 const status = 'inactive'
  const regrecord =new Reg({username:username,password:password,email:email,status:status})
  await regrecord.save()
  res.redirect('/')
})

router.get('/login',(req,res)=>{
    res.render('login.ejs')
})

router.post('/loginCheck',async(req,res)=>{
 const username =req.body.username
 const password =req.body.password
const regData= await Reg.findOne({username:username})
if(regData !== null){
    if(regData.password ==password ){
        if(regData.status =='active'){
            res.redirect('/')
        }else{
            console.log("your account is suspended")
        }
        
    }else{
        res.redirect('/login')
    }
   
}else{
    res.redirect('/login')
}


})

module.exports=router;